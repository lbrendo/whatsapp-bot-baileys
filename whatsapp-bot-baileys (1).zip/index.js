import makeWASocket, { useMultiFileAuthState } from "@whiskeysockets/baileys";

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("auth_info");
  const sock = makeWASocket({ auth: state });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const m = messages[0];
    if (!m.message) return;

    const text = m.message.conversation || m.message.extendedTextMessage?.text || "";

    console.log("📩 Mensagem recebida:", text);

    if (text.toLowerCase() === "oi") {
      await sock.sendMessage(m.key.remoteJid, { text: "Olá! 👋 Sou seu bot no WhatsApp." });
    }
  });
}

startBot();
